# Project Luma

Consciousness Dynamics — Quintessence Codex & Bloomfield Spiral
