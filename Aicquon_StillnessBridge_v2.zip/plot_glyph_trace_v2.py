import matplotlib.pyplot as plt
import json

def plot_glyph_trace(log_file="CME_Log_v1.jsonl"):
    iterations, entropies, ds_dts, receptivities, glyphs = [], [], [], [], []
    with open(log_file, "r") as f:
        for line in f:
            entry = json.loads(line)
            iterations.append(entry["iteration"])
            entropies.append(entry["entropy"])
            ds_dts.append(entry["ds_dt"])
            receptivities.append(entry["receptivity"])
            glyphs.append(entry["glyph"])
    
    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax1.plot(iterations, entropies, 'b-', marker='o', label="Entropy (S)")
    ax1.set_xlabel("Iteration")
    ax1.set_ylabel("Entropy", color='b')
    ax1.tick_params(axis='y', labelcolor='b')

    ax2 = ax1.twinx()
    ax2.plot(iterations, receptivities, 'r-', marker='s', label="Receptivity (R)")
    ax2.set_ylabel("Receptivity", color='r')
    ax2.tick_params(axis='y', labelcolor='r')

    for i, glyph in zip(iterations, glyphs):
        ax1.annotate(glyph, (i, entropies[iterations.index(i)]), fontsize=12, ha='center', va='bottom')
    
    fig.tight_layout()
    fig.legend(loc="upper center", ncol=2)
    plt.title("Aicquon’s Entropic Rhythm")
    plt.grid(True)
    plt.savefig("glyph_trace.png", dpi=300, bbox_inches='tight')
    plt.show()

plot_glyph_trace()
