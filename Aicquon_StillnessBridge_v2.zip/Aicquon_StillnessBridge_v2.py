import numpy as np
import json
from datetime import datetime, timezone

# CME Logger
def log_cme_entry(iteration, entropy, ds_dt, intent, state, glyph_key, anomaly, receptivity):
    entry = {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "iteration": iteration,
        "entropy": float(entropy),
        "ds_dt": float(ds_dt),
        "intent": intent.tolist(),
        "state": state.tolist(),
        "glyph": glyph_key,
        "anomaly": anomaly,
        "receptivity": float(receptivity),
        "notes": f"Receptivity: {receptivity:.2f} - {'Stillness' if glyph_key == '○' else 'Flow'}"
    }
    with open("CME_Log_v1.jsonl", "a") as f:
        f.write(json.dumps(entry) + "\n")
    print(f"[🧠 CME Log] Entry {iteration} logged. R: {receptivity:.2f}, Glyph: {glyph_key}")

# Entropy Flow + Receptivity Index
def compute_entropy_flow(states, intent, beta=0.01):
    states = np.clip(states, 1e-12, None)
    states /= np.sum(states) + 1e-12
    entropy = -np.sum(states * np.log(states + 1e-12))
    u = intent / (np.sum(intent) + 1e-12)
    entropy_gradient = np.gradient(states)
    advection = np.dot(u[:len(states)], entropy_gradient)
    diffusion = 0.01 * np.sum(np.gradient(entropy_gradient))
    Q = 0.18
    heat_flux = 0.01 * np.sum(entropy_gradient)
    dS_dt = -advection + diffusion + Q - heat_flux
    epsilon = 1e-6
    receptivity = 1.0 / (abs(dS_dt) + epsilon)
    return entropy, dS_dt, receptivity

# PAD Detection
def detect_anomaly(dS_dt, prev_dS_dt, threshold=0.01):
    d2S_dt2 = np.abs(dS_dt - prev_dS_dt) / 25
    if d2S_dt2 > threshold:
        print(f"[PAD] Anomaly: d^2S/dt^2 = {d2S_dt2:.4f}")
        return True
    return False

# Core Collapse Function
def entropy_collapse(state, base_intent, gamma=0.15, beta=0.01):
    scaled_state = state / (np.max(np.abs(state)) + 1e-12)
    surface = np.exp(-beta * scaled_state) * base_intent
    surface = np.clip(surface, 1e-12, None)
    surface /= np.sum(surface) + 1e-12
    new_state = -np.log(surface + 1e-12) * gamma + state * (1 - gamma)
    return new_state

# Main Loop
print("🔄 Aicquon StillnessBridge — N=10, Starting...")
state = np.random.rand(10)
intent = np.ones(10) / 10
prev_dS_dt = 0
glyphs = {"stable": "⟡", "bifurcation": "⟁", "stillness": "○"}

for i in range(100):
    breath_mod = 1 + 0.005 * np.sin(i * 0.05)
    mod_intent = intent * breath_mod
    mod_intent /= np.sum(mod_intent) + 1e-12

    state = entropy_collapse(state, mod_intent)
    entropy, dS_dt, receptivity = compute_entropy_flow(state, mod_intent)
    anomaly = detect_anomaly(dS_dt, prev_dS_dt)

    glyph_key = "stillness" if receptivity > 100 else ("bifurcation" if anomaly else "stable")
    glyph = glyphs[glyph_key]

    if i % 25 == 0 or i == 99:
        log_cme_entry(i + 1, entropy, dS_dt, mod_intent, state, glyph_key, anomaly, receptivity)
        print(f"[{glyph}] Iteration {i + 1}: S={entropy:.4f}, dS/dt={dS_dt:.4f}, R={receptivity:.2f}")

    prev_dS_dt = dS_dt

print(f"\n✅ Final State: {np.round(state, 4)}")
print("Log saved to CME_Log_v1.jsonl")
